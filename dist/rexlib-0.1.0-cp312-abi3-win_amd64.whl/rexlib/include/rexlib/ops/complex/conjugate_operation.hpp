// SPDX-License-Identifier: GPL-3.0-only

#pragma once

#include <rexlib/core/operation/operation_declaration_macros.hpp>
#include <rexlib/ops/ops_component.hpp>
#include <rexlib/ops/rules/shape_rules.hpp>
#include <rexlib/ops/rules/type_rules.hpp>

namespace rexlib
{
namespace ops
{

/**
 * @brief Conjugate each element of the input array.
 *
 * Real operands are admitted and left unchanged, so that code
 * generic over the element type does not need a special case.
 */
REXLIB_DECLARE_OPERATION(
	conjugate,
	ops_component,
	REXLIB_OPERANDS("result"),
	REXLIB_OPERANDS("value"),
	unary_elementwise_shape_rule,
	unary_homogeneous_rule<arithmetic_type_domain>
);

} // namespace ops
} // namespace rexlib
