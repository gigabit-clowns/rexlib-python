// SPDX-License-Identifier: GPL-3.0-only

#pragma once

#include <rexlib/core/operation/operation_descriptor.hpp>
#include <rexlib/core/operation/operation_id.hpp>
#include <rexlib/core/operation/operation_signature.hpp>

#include <rexlib/core/platform/dynamic_shared_object.h>

namespace rexlib
{

class operation_id;

/**
 * @brief Abstract class that describes an operation.
 *
 * Subclasses of it may implement the specific behavior for each of the
 * operations.
 */
class REXLIB_API operation
{
public:
	operation() noexcept;
	operation(const operation &other) = delete;
	operation(operation &&other) = delete;
    virtual ~operation();

	operation& operator=(const operation &other) = delete;
	operation& operator=(operation &&other) = delete;

	/**
	 * @brief Get an identifier that uniquely represents this operation.
	 *
	 * The identifier is what binds an operation to the program builders
	 * implementing it, so a subclass that behaves as its base must report
	 * the base's identifier rather than one of its own. The default
	 * implementation derives it from the dynamic type and therefore does
	 * not; override it, as @ref basic_operation does, whenever an
	 * operation may be derived from.
	 *
	 * @return operation_id The operation id.
	 */
	virtual
	operation_id get_id() const noexcept;

	/**
	 * @brief Get the static description of this operation.
	 *
	 * Holds the operation's name and the name of each of its operands, so
	 * that whatever rejects a launch configuration can say which operand it
	 * objected to. @ref basic_operation supplies it from the operation's
	 * declaration.
	 *
	 * @return const operation_descriptor& The description.
	 */
	virtual
	const operation_descriptor& get_descriptor() const noexcept = 0;

	/**
	 * @brief Get the signature deciding the shape and data type of the
	 * operands of this operation.
	 *
	 * @return const operation_signature& The signature.
	 */
	virtual
	const operation_signature& get_signature() const noexcept = 0;
};

} // namespace rexlib
