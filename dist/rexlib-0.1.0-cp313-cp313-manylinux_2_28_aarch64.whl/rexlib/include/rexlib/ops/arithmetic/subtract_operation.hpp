// SPDX-License-Identifier: GPL-3.0-only

#pragma once

#include <rexlib/core/dispatch/basic_operation.hpp>
#include <rexlib/ops/ops_component.hpp>
#include <rexlib/ops/policies/elementwise_operation_shape_policy.hpp>
#include <rexlib/ops/rules/operand_type_rules.hpp>

namespace rexlib
{
namespace ops
{

/**
 * @brief Subtract the elements of two input arrays into an output array.
 *
 * Boolean operands are subtracted as an exclusive disjunction.
 */
REXLIB_DECLARE_OPERATION(
	subtract,
	ops_component,
	REXLIB_OPERANDS("result"),
	REXLIB_OPERANDS("left", "right"),
	elementwise_operation_shape_policy,
	binary_homogeneous_rule<>
);

} // namespace ops
} // namespace rexlib
