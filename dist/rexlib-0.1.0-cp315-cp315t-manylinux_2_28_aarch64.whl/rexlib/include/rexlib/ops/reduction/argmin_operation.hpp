// SPDX-License-Identifier: GPL-3.0-only

#pragma once

#include <rexlib/core/operation/operation_declaration_macros.hpp>
#include <rexlib/ops/ops_component.hpp>
#include <rexlib/ops/parameters/reduction_axes.hpp>
#include <rexlib/ops/rules/shape_rules.hpp>
#include <rexlib/ops/rules/type_rules.hpp>

namespace rexlib
{
namespace ops
{

/**
 * @brief Locate the smallest element along the reduced axes.
 *
 * The result holds indices rather than values, so it is int64 whatever
 * the operand type was.
 */
REXLIB_DECLARE_PARAMETRIC_OPERATION(
	argmin,
	ops_component,
	REXLIB_OPERANDS("index"),
	REXLIB_OPERANDS("value"),
	extremum_reduction_shape_rule,
	reduction_axes,
	unary_fixed_output_rule<
		numerical_type::int64,
		domain_difference<any_type_domain, complex_type_domain>
	>
);

} // namespace ops
} // namespace rexlib
