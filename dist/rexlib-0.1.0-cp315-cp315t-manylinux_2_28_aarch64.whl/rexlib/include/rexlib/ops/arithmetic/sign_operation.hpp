// SPDX-License-Identifier: GPL-3.0-only

#pragma once

#include <rexlib/core/operation/operation_declaration_macros.hpp>
#include <rexlib/ops/ops_component.hpp>
#include <rexlib/ops/rules/shape_rules.hpp>
#include <rexlib/ops/rules/type_rules.hpp>

namespace rexlib
{
namespace ops
{

/**
 * @brief Extract the sign of each element of the input array.
 *
 * Complex operands yield the unit value with the same argument, which is
 * the closest analogue of a sign the complex plane has, and keeps the
 * result in the operand type.
 */
REXLIB_DECLARE_OPERATION(
	sign,
	ops_component,
	REXLIB_OPERANDS("result"),
	REXLIB_OPERANDS("value"),
	unary_elementwise_shape_rule,
	unary_homogeneous_rule<arithmetic_type_domain>
);

} // namespace ops
} // namespace rexlib
