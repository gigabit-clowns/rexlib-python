// SPDX-License-Identifier: GPL-3.0-only

#pragma once

#include <rexlib/core/operation/shape_rule/core_dimensions.hpp>
#include <rexlib/core/operation/shape_rule/core_placement.hpp>
#include <rexlib/core/operation/shape_rule/extent_pivot.hpp>
#include <rexlib/core/operation/shape_rule/extent_slot.hpp>
#include <rexlib/core/operation/shape_rule/output_batch.hpp>
#include <rexlib/core/operation/shape_rule/same_extent_transform.hpp>
#include <rexlib/core/operation/shape_rule/trailing_core.hpp>

#include <rexlib/core/meta/type_list.hpp>
#include <rexlib/core/platform/constexpr.hpp>

#include <cstddef>
#include <type_traits>
#include <utility>

namespace rexlib
{

namespace detail
{

template <bool... Values>
struct shape_rule_bool_pack;

template <bool... Values>
struct shape_rule_all_of
	: std::is_same<
		shape_rule_bool_pack<true, Values...>,
		shape_rule_bool_pack<Values..., true>
	>
{
};

template <bool... Values>
struct shape_rule_any_of
	: std::integral_constant<bool, !shape_rule_all_of<(!Values)...>::value>
{
};

template <std::size_t PivotCount, typename SlotList>
struct slots_name_declared_pivots;

template <std::size_t PivotCount, typename... Slots>
struct slots_name_declared_pivots<PivotCount, type_list<Slots...>>
	: shape_rule_all_of<(Slots::pivot_index < PivotCount)...>
{
};

template <std::size_t PivotCount, typename Core>
struct core_names_declared_extents
	: slots_name_declared_pivots<PivotCount, typename Core::slot_list_type>
{
};

template <std::size_t PivotCount, typename Cores>
struct cores_name_declared_extents;

template <std::size_t PivotCount, typename... Cores>
struct cores_name_declared_extents<PivotCount, type_list<Cores...>>
	: shape_rule_all_of<
		core_names_declared_extents<PivotCount, Cores>::value...
	>
{
};

template <std::size_t Extent, typename SlotList>
struct slots_bind_extent;

template <std::size_t Extent, typename... Slots>
struct slots_bind_extent<Extent, type_list<Slots...>>
	: shape_rule_any_of<(
		Slots::pivot_index == Extent &&
		std::is_same<
			typename Slots::transform_type,
			same_extent_transform
		>::value
	)...>
{
};

template <std::size_t Extent, typename Core>
struct core_binds_extent
	: slots_bind_extent<Extent, typename Core::slot_list_type>
{
};

template <std::size_t Extent, typename Cores>
struct cores_bind_extent;

template <std::size_t Extent, typename... Cores>
struct cores_bind_extent<Extent, type_list<Cores...>>
	: shape_rule_any_of<core_binds_extent<Extent, Cores>::value...>
{
};

template <typename Extents, typename InputCores, typename Indices>
struct input_extents_bound;

template <typename... Extents, typename InputCores, std::size_t... Indices>
struct input_extents_bound<
	type_list<Extents...>,
	InputCores,
	std::index_sequence<Indices...>
>
	: shape_rule_all_of<(
		Extents::source != extent_pivot_source::inputs ||
		cores_bind_extent<Indices, InputCores>::value
	)...>
{
};

template <typename Extents>
struct extents_from_operation;

template <typename... Extents>
struct extents_from_operation<type_list<Extents...>>
	: shape_rule_any_of<(Extents::source == extent_pivot_source::operation)...>
{
};

template <typename Cores>
struct cores_without_run;

template <typename... Cores>
struct cores_without_run<type_list<Cores...>>
	: shape_rule_all_of<(!Cores::has_run)...>
{
};

template <typename Cores>
struct cores_empty;

template <typename... Cores>
struct cores_empty<type_list<Cores...>>
	: shape_rule_all_of<(Cores::axis_count == 0 && !Cores::has_run)...>
{
};

template <typename Core>
struct core_carries_axes
	: std::integral_constant<bool, (Core::axis_count > 0 || Core::has_run)>
{
};

template <typename Cores>
struct cores_any_carry_axes;

template <typename... Cores>
struct cores_any_carry_axes<type_list<Cores...>>
	: shape_rule_any_of<core_carries_axes<Cores>::value...>
{
};

template <typename Cores>
struct first_core_carrying_axes
{
	using type = void;
};

template <typename First, typename... Rest>
struct first_core_carrying_axes<type_list<First, Rest...>>
{
	using type = typename std::conditional<
		core_carries_axes<First>::value,
		First,
		typename first_core_carrying_axes<type_list<Rest...>>::type
	>::type;
};

template <std::size_t AxisCount, bool HasRun, typename Cores>
struct cores_empty_or_alike;

template <std::size_t AxisCount, bool HasRun, typename... Cores>
struct cores_empty_or_alike<AxisCount, HasRun, type_list<Cores...>>
	: shape_rule_all_of<(
		(Cores::axis_count == 0 && !Cores::has_run) ||
		(Cores::axis_count == AxisCount && Cores::has_run == HasRun)
	)...>
{
};

template <typename Reference, typename Inputs, typename Outputs>
struct cores_alike_to
	: std::integral_constant<
		bool,
		cores_empty_or_alike<
			Reference::axis_count,
			Reference::has_run,
			Inputs
		>::value &&
		cores_empty_or_alike<
			Reference::axis_count,
			Reference::has_run,
			Outputs
		>::value
	>
{
};

template <typename Inputs, typename Outputs>
struct cores_alike_to<void, Inputs, Outputs>
	: std::true_type
{
};

template <typename Inputs, typename Outputs>
struct named_cores_alike
	: cores_alike_to<
		typename first_core_carrying_axes<Inputs>::type,
		Inputs,
		Outputs
	>
{
};

} // namespace detail

/**
 * @brief Declarative shape rule for the operands of an operation.
 *
 * Every axis of an operand is either a batch axis or a core axis. The
 * batch axes of all operands broadcast together, while the core axes are
 * declared per operand by a core_dimensions, whose slots relate them through
 * a small set of extent variables. Core axes never broadcast: every axis
 * naming an extent variable must agree with it.
 *
 * The rule is lowered to tables, so a single interpreter serves every
 * operation. Values that depend on the operation instance, such as the axes
 * it names, are read through the accessors the rule declares.
 *
 * @tparam Pivots type_list of extent_pivot declarations.
 * @tparam Outputs type_list of core_dimensions, one per output operand, in
 * signature order.
 * @tparam Inputs type_list of core_dimensions, one per input operand, in
 * signature order.
 * @tparam Placement Where the core axes lie: trailing_core or named_core.
 * @tparam Batch Which batch axes an output supplied in advance may have.
 *
 * @see extent_pivot
 * @see core_dimensions
 */
template <
	typename Pivots,
	typename Outputs,
	typename Inputs,
	typename Placement = trailing_core,
	output_batch Batch = output_batch::exact
>
struct operand_shape_rule
{
	using pivot_list_type = Pivots;
	using output_core_list_type = Outputs;
	using input_core_list_type = Inputs;
	using placement_type = Placement;

	static REXLIB_CONST_CONSTEXPR output_batch batch = Batch;

	static REXLIB_CONST_CONSTEXPR std::size_t pivot_count =
		type_list_size<Pivots>::value;
	static REXLIB_CONST_CONSTEXPR std::size_t output_count =
		type_list_size<Outputs>::value;
	static REXLIB_CONST_CONSTEXPR std::size_t input_count =
		type_list_size<Inputs>::value;

	/**
	 * @brief Whether the rule reads values of the operation instance.
	 */
	static REXLIB_CONST_CONSTEXPR bool requires_parameters =
		Placement::placement == core_placement::named ||
		detail::extents_from_operation<Pivots>::value;

	static_assert(
		pivot_count <= max_extent_pivot_count,
		"A shape rule declares more extent variables than a resolution can "
		"hold. Raise max_extent_pivot_count if this is genuinely needed."
	);

	static_assert(
		detail::cores_name_declared_extents<pivot_count, Outputs>::value &&
		detail::cores_name_declared_extents<pivot_count, Inputs>::value,
		"A core axis names an extent variable the rule does not declare."
	);

	static_assert(
		detail::input_extents_bound<
			Pivots,
			Inputs,
			std::make_index_sequence<pivot_count>
		>::value,
		"An extent variable bound by the inputs is not carried untransformed "
		"by any input axis, so nothing determines it."
	);

	static_assert(
		Placement::placement == core_placement::named ||
		(
			detail::cores_without_run<Outputs>::value &&
			detail::cores_without_run<Inputs>::value
		),
		"A run is as long as the axes the operation instance names, so only "
		"a rule whose core axes are named may declare one."
	);

	static_assert(
		Placement::placement != core_placement::named ||
		detail::cores_any_carry_axes<Inputs>::value,
		"A rule whose core axes are named needs an input carrying them."
	);

	static_assert(
		Placement::placement != core_placement::named ||
		detail::named_cores_alike<Inputs, Outputs>::value,
		"Under named placement every core carrying the named axes must "
		"declare as many axes and runs as the others."
	);

	static_assert(
		Batch != output_batch::broadcast_target ||
		(
			Placement::placement == core_placement::trailing &&
			detail::cores_empty<Outputs>::value &&
			detail::cores_empty<Inputs>::value
		),
		"Only an operation without core axes may write into outputs larger "
		"than its inputs broadcast to."
	);
};

} // namespace rexlib
