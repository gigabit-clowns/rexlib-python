# Working on rexlib-python

rexlib-python is the Python binding for [rexlib](https://github.com/gigabit-clowns/rexlib),
a device-agnostic array computing library with a pluggable backend
architecture. It is a binding and nothing more: every computation happens in
C++, and this repository decides only what the Python side of that API looks
like.

Keep this file true. When a change makes something here wrong or missing —
a moved directory, a new convention, a dependency, a workflow — update it in
the same pull request that causes it.

## Layout

| Path | Holds |
|---|---|
| `src/` | The nanobind binding, 35 `.cpp` and 36 `.hpp`, compiled into the `rexlib._binding` extension |
| `python/rexlib/` | The Python package, 9 `.py`: everything the binding cannot express |
| `tests/` | pytest suites, mirroring the binding's module structure |
| `tests/assets/` | Two dummy plugins, built by CMake, that the plugin tests discover |
| `scripts/` | Development tools: the test runner, the stub generator and collector, the wheel check |
| `cmake/modules/` | `python_stubs.cmake`, which installs the type stubs |
| `conf/` | `coverage.ini` |
| `external/rexlib` | The rexlib the repository is developed against, a submodule |

There are two sides, and which one a change belongs to is the first question
to ask.

`src/` mirrors rexlib's own directory structure, and the module it produces
mirrors the C++ API: same names, same argument order, same required arguments.
It does not decide anything. `python/rexlib/` is where the API becomes Python:
default arguments, implicit context, operators, process-wide state. Its
modules carry a leading underscore and `__init__.py` re-exports what they
hold, so that the public surface is one flat namespace rather than a set of
import paths.

A public subpackage is the exception to that, and `em/` is the one: its module
path *is* the API, so the directories are named without an underscore and each
carries an `__all__` of its own. Anything private inside one still takes the
underscore.

`em` holds nothing at the moment. Image I/O was its one area, and it now lives
in [vitrio](https://github.com/gigabit-clowns/vitrio), a package of its own
that takes and gives arrays through DLPack and the buffer protocol. Until
rexlib gains another area there is no `src/em/` and `src/main.cpp` creates no
`em` submodule, and the import of the package in `python/rexlib/__init__.py`
is commented out.

The rule that follows: if a change could be expressed in either place, it goes
in `python/rexlib/`. C++ is the expensive side to change and the one that has
to keep matching rexlib.

### The binding's modules

The submodules follow rexlib's directories, not its namespaces. rexlib has
four namespaces — `rexlib`, `ops`, `em` and `backends::cpu` — and none of
`hardware`, `dispatch`, `ndarray`, `numerical` or `functional` is one of
them: everything under those directories is flat in `namespace rexlib`,
`rexlib::device` and `rexlib::array` and `rexlib::add` alike. The paths are
the only place rexlib separates these areas, so the paths are what the
submodule names come from.

It reaches through nesting where rexlib's directories nest. An area under
`em/` sits inside `namespace em` the way `core/hardware/` sits inside
`namespace rexlib`, so it binds as `em.<area>` rather than as `em`, even where
its functions carry no qualifier of their own. The path is what keeps the
areas apart, which is why it is the path and not the function name that names
them. See #143.

`_binding` carries at its top level what the directories below it sit in:

| Module | From | Holds |
|---|---|---|
| `_binding` | `src/core/*.cpp` | `Version`, `Plugin`, `PluginManager`, `ServiceCatalog`, `rexlib_version`, `rexlib_binding_version` |
| `_binding.numerical` | `src/core/numerical/` | `NumericalType`, and the `float16_t` type caster |
| `_binding.ndarray` | `src/core/ndarray/` | `Array` and its buffer protocol, `ArrayDescriptor`, the functions that put an array's memory in a DLPack capsule and take one out, and the type caster that loads `const_array_ref` and `array_ref` from an `Array` |
| `_binding.hardware` | `src/core/hardware/` | Devices, sessions, queues, memory resources |
| `_binding.dispatch` | `src/core/dispatch/` | `ExecutionContext`, `Dispatcher`, `ProgramManager` |
| `_binding.functional` | `src/functional/` | The operations, each taking an explicit context |

A submodule is created by the `main.cpp` above it, which then hands it to the
`bind_` function of the directory it stands for: `src/main.cpp` creates
`hardware` and hands it to `bind_hardware`, and a directory that nests does
the same one level down. Each names its submodules in the order the
declarations need.

### The package's modules

| Module | Adds |
|---|---|
| `_paths.py` | Locates the rexlib shipped inside the package; on Windows puts it on the DLL search path |
| `_catalog.py` | The process-wide default `ServiceCatalog` |
| `_session_pool.py` | One `DeviceSession` per device, process-wide |
| `_context.py` | The execution context active on the current thread |
| `_device.py` | `rexlib.device(...)`, the `with` block that activates one |
| `_functional.py` | The operations again, with `context` defaulting to the active one |
| `_ndarray.py` | Installs onto `Array` the Python operators, `__array__` and the two DLPack methods; holds `from_dlpack` |
| `em/` | The electron microscopy areas, one module each. None yet |

`_paths` is imported first in `__init__.py`, and the order matters: on Windows
nothing else imports until the bundled library is findable. `_ndarray` is
imported for its side effect, before anything can hand out an `Array`.

DLPack is split between the two sides the way everything else is. The binding
builds a capsule and reads one, and reports the version of DLPack it was
compiled against. `_ndarray` holds what the protocol lets either side ask
for: the stream, the device, the version and the copy.

numpy is not imported by the package. `__array__` imports it when it is
called, and only numpy calls it.

## Building

The binding needs a rexlib to link. The submodule is the one it is developed
against, so clone with it:

```
git clone --recurse-submodules https://github.com/gigabit-clowns/rexlib-python.git
```

Build that submodule into a prefix, then install this project against it:

```
cmake -S external/rexlib -B build/rexlib -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=~/.local -DCMAKE_INSTALL_LIBDIR=lib -DBUILD_TESTING=OFF
cmake --build build/rexlib --target install --parallel $(nproc)

CMAKE_PREFIX_PATH=~/.local CMAKE_BUILD_PARALLEL_LEVEL=$(nproc) \
  pip install . --no-build-isolation -v -Ccmake.define.REXLIB_PYTHON_BUILD_TESTING=ON
```

`pip install` is the way in, not `cmake --build`: scikit-build-core drives
CMake, and the install rules are what put the package together. A CMake build
on its own is what CI uses to get a compilation database for the scanner, not
a way to get a working package.

Installed this way the package carries no rexlib, and the extension's RPATH
names, after the package's own library directory, the one rexlib was found
in, so the package works where it was built. Windows has no RPATH: there the
rexlib DLL has to be on the loader's search path. A wheel carries rexlib, as
does any build given `REXLIB_PYTHON_STAGE_PREFIX` or one that builds
`external/rexlib`, and names nothing outside itself.

That build is thrown away with its directory, so installing twice compiles the
binding twice. `SKBUILD_BUILD_DIR` names one to keep and is left to whoever is
installing rather than set here — the README carries it. It is deliberately
not in `pyproject.toml`: the gain is a developer's repeated install, while the
cost, a CMake cache that outlives the options it was configured with, would
fall on every user and on six wheel jobs that already hit their compiler cache
without it.

CMake 3.18 is the minimum, and 3.26 with `REXLIB_PYTHON_STABLE_ABI`, the
first whose FindPython has `Development.SABIModule`. The binding is C++20,
unlike rexlib itself, which is C++14: nothing here has to build on the
compilers rexlib supports, only on the ones that build wheels.
`CMAKE_CXX_STANDARD_REQUIRED` is off all the same.

nanobind and DLPack are fetched, each pinned in `CMakeLists.txt` as a git tag
that Renovate follows. DLPack is one header, and only the header is taken:
its own build file is not read. rexlib is found with `find_package` and only
built from `external/rexlib` when none is found, which is what makes a source
distribution installable on a machine with no rexlib.

Options:

| Option | Default | Effect |
|---|---|---|
| `REXLIB_PYTHON_BUILD_TESTING` | `BUILD_TESTING` | Builds the dummy plugins the tests need |
| `REXLIB_PYTHON_INSTALL` | `ON` | Generates the install rules |
| `REXLIB_PYTHON_INSTALL_DIR` | `Python_SITEARCH`; under scikit-build-core, always the wheel's platlib | Where the package is installed |
| `REXLIB_PYTHON_STAGE_PREFIX` | empty | A rexlib prefix to copy inside the package |
| `REXLIB_PYTHON_STUBS_DIR` | empty | Pre-generated `.pyi` files to install instead of generating them |
| `REXLIB_PYTHON_STABLE_ABI` | `OFF`, `ON` from `pyproject.toml` | Builds the extension against the stable ABI of Python 3.12 |
| `REXLIB_PYTHON_REXLIB_VERSION` | `0.1` | The rexlib version `find_package` asks for |

`REXLIB_PYTHON_BUILD_TESTING` is separate from `BUILD_TESTING` because
dependencies of dependencies write that one into the cache, and this project's
tests should not be at their mercy.

`REXLIB_PYTHON_STABLE_ABI` is what makes one wheel serve Python 3.12 and every
later one, with `wheel.py-api = "cp312"` beside it in `pyproject.toml`.
nanobind falls back to the interpreter's own ABI where the stable one cannot
serve — before 3.12, and on a free-threaded interpreter — and
scikit-build-core tags those wheels accordingly. The suffix of the module is
nanobind's to choose from what scikit-build-core reports, which is the target
interpreter's when cibuildwheel cross-compiles.

`REXLIB_PYTHON_STAGE_PREFIX` is copied whole, so it has to hold rexlib and
nothing else, and no symlinks — a wheel stores a symlink as a second full copy
of a 50 MB library. rexlib's `rexlib_runtime` and `rexlib_development`
components install exactly that.

Unlike rexlib, `src/CMakeLists.txt` globs its sources. A new `.cpp` is picked
up by reconfiguring and needs naming nowhere. The reasons rexlib lists its
sources explicitly do not apply here: there is one target, and nothing in the
binding registers itself through objects at namespace scope, so link order
decides nothing.

## Type stubs

The extension's `.pyi` files are generated while it is built, by
`scripts/generate_stubs.py` through nanobind's stubgen, run from the fetched
sources, and land in `rexlib/_binding/` beside it. They are not in the
repository and there is nothing to run by hand.

Generating them imports the extension, which a cross-compiling build cannot
do. Those builds are handed stubs made elsewhere through
`REXLIB_PYTHON_STUBS_DIR`; stubs describe the Python API, so the same ones are
correct on every platform. A build that can neither generate nor be given them
fails rather than producing an untyped package.

The package is typed — `py.typed` ships — so a change to the binding's
signatures is a change to the stubs, generated for free, and a change to
`python/rexlib/` is only as typed as it was written.

Importing the extension imports the package first, so stubgen sees what
`_ndarray.py` installs onto `Array` and writes it into the class with its
annotations. It does so only for a function whose name and module are those of
a method of `Array`; any other it renders as an import, which is not a stub.
`_install` gives each one that name and module.

A submodule that holds submodules of its own becomes a directory of stubs
rather than one file: `_binding/<name>/__init__.pyi` beside one `.pyi` for
each it holds. None does today, and every step that moves stubs carries that
tree all the same: `scripts/collect_stubs.py` copies it and the artifact
holding it is uploaded as a directory. A flat `*.pyi` glob at either step
takes the top level and drops the rest, which fails nothing and publishes
wheels typed everywhere except the area that was just added.

## Conventions

### The binding

Every bound entity gets a `.hpp` and a `.cpp`. The header declares a class
alias and the two functions the source defines:

```cpp
using device_class = nanobind::class_<device, PyDevice>;

device_class declare_device(nanobind::module_ &m);
void define_device(device_class &c);
```

`declare_X` creates the type and nothing else. `define_X` fills it in. A
namespace's `main.cpp` calls every `declare_` first and every `define_`
afterwards, which is what lets any binding refer to any other type regardless
of the order they appear in — a default argument, a return type, a base class.
Splitting the two is the whole point; do not collapse them because a
particular type happens not to need it today.

`define_X` takes a second `nanobind::module_ &` when it also registers
something at module level, which is how the free functions beside a type are
bound: `define_device_manager` adds `get_device_manager`, `define_version`
adds the `rexlib_version` attribute.

A source declares `namespace nb = nanobind;` inside `namespace rexlib` and
writes `nb::` throughout, signatures included. A header writes `nanobind::`
in full, since an alias there would reach every source that includes it.

Managers are reached through a module-level getter taking a `ServiceCatalog`,
never constructed: `get_device_manager(catalog)`, `get_program_manager(catalog)`.
They are services the catalog owns.

Names follow rexlib on the C++ side — `lower_case`, `m_` on private members —
and Python on the bound side: `CamelCase` types, `lower_case` functions and
properties. A C++ getter pair becomes a property, not `get_x()`/`set_x()`.

Every argument is named with `nb::arg`. An operation is bound by pointer,
straight from rexlib, with its optional out parameter, the `array *` rexlib
takes, as `nb::arg("out").none() = nb::none()`; nanobind hands `None` in as
`nullptr`. The `const_array_ref` and `array_ref` rexlib takes arrive through
`array_ref_caster.hpp`. A function of the binding's own sits between only
where something has to be converted, as the fill value of `full` is.

A type caster for a standard type — `<nanobind/stl/string.h>`,
`shared_ptr.h`, `vector.h`, `optional.h` and the like — is included by every
source that binds a signature carrying that type, written out or reached
through a member pointer. Without it nanobind still compiles, taking the type
for a bound one, and fails at run time. There are no holder types: a
`shared_ptr` to a bound type crosses through `shared_ptr.h`.

A type that defines `__eq__` and no `__hash__` should be unhashable, so that
it cannot be a dictionary key or go in a set, as Python makes such a class.
nanobind does not: the type would hash by identity, and two equal values would
be two keys. Where rexlib gives the type a `hash()` of its own, as
`array_descriptor` does, forward it. Where it does not, set `__hash__` to
`None`, as `Version` and `DeviceIndex` do. Writing the hash is rexlib's to do
rather than this binding's; `_session_pool.py` keys on a `(backend, id)` tuple
in the meantime.

A binding that blocks releases the GIL: held through the wait, it would
freeze every other Python thread for its duration. Where the whole function
blocks, that is `nb::call_guard<nb::gil_scoped_release>()`. nanobind converts
the arguments before the guard is constructed and the return value after it is
destroyed, so nothing touches Python without it.

Where only part of a function blocks, the release is a
`nb::gil_scoped_release` in a block around that part. Handing out an array's
memory is the case: it waits for the commands that still use the array, and
then builds a Python object.

`rexlib::array` is move-only, and anything taking one by value has to be given
`destination.share()` rather than the caller's own, or `source.share_const()`
where it takes a `const_array`. Bound plainly, the binding would move the
array out of the Python object and hand the caller back an empty one.

A type rexlib parses from a string carries a `from_string` static method and
no constructor that parses, as `DeviceIndex` does. A constructor is left free
to give a lone string another meaning, and a parsing overload would compete
for that signature rather than add to it. `from_string` is the inverse of
`__str__` and raises `ValueError`, which is what the `bool` of rexlib's
`parse_*` becomes on this side.

Lifetimes are stated: `nb::keep_alive` where an object borrows from another,
`nb::rv_policy::reference_internal` where a getter hands out a
reference into its owner. Getting this wrong does not fail a test, it crashes
a user.

A rexlib type with no Python counterpart gets a `type_caster`, not a bound
class — see `float16_caster.hpp`, which converts `float16_t` through `float`,
and `array_ref_caster.hpp`, which loads a reference to an array from an
`Array` and gives it `Array`'s name in the stubs.

`PyX` trampolines, declared with `NB_TRAMPOLINE`, live in the header, not the
source, because they are part of the `class_` alias callers see.

`Array`'s buffer protocol is a pair of type slots in `array.cpp`, nanobind
binding no buffer of its own. They check the layout a consumer asks for, and
keep what the view points to besides the memory in its `internal` field.

### Memory that crosses the border

The host reaches an array's memory through rexlib's `get_host_data`, never
through `get_storage()->get_host_ptr()`. `get_host_data` waits for the
commands that still use the array and refuses storage the host cannot reach.
The buffer protocol and `to_dlpack` both go through it.

Only host memory crosses, in both directions, and nothing is moved or copied
on a caller's behalf. The one exception is a read-only source, which
`from_dlpack` copies because an `Array` can always be written to.

A capsule handed out owns a `shared_ptr` to the buffer, not a reference to the
`Array`. Its deleter therefore touches no Python object and runs without the
GIL, on whatever thread the consumer calls it from.

Memory taken in is held by `dlpack_buffer`, a `rexlib::buffer` the binding
implements. It is the one class in `src/` that binds nothing. rexlib has no
call that adopts foreign memory and needs none: `buffer` is the interface,
and whoever holds the memory implements it.

A capsule is renamed once its tensor is taken, and only then. Everything that
can refuse a tensor runs before, so a refused tensor stays with its capsule
and is released by it.

A capsule is created with `PyCapsule_New`, not `nb::capsule`. The cleanup of
the latter is handed the pointer whatever the capsule's name, and would
release a tensor a consumer has already taken.

The binding builds with `-Wall -Wextra -Wpedantic`, `/W4 /WX` on MSVC.
nanobind's headers and Python's are system headers to it
(`NB_SUPPRESS_WARNINGS`), so the warnings are the binding's own.

### The package

Indentation is tabs, on both sides. Lines stay within 80 columns.

`from __future__ import annotations` goes at the top of every module that
annotates anything, so that no annotation is evaluated at import. That is what
lets one name something imported only under `TYPE_CHECKING`, such as a type
of a library the package does not depend on at run time. Python 3.14 defers
annotations by itself; until 3.13 is dropped, the import is what does it.

Module-level state uses two leading underscores — `__pool`, `__default_catalog`,
`__local`. Python mangles nothing at module scope, so this is a convention
rather than a mechanism, and it is the one that marks the difference between
the module's own state and something a caller might reasonably reach for.

Public functions carry a docstring with `Args:` and `Returns:`; ruff enforces
their presence under pydocstyle, in pep257 convention.

`__init__.py` re-exports with `as`, `from ._x import y as y`, which is what
makes the name public to a type checker, and lists everything again in
`__all__`. Both are needed and both are checked.

Operations live at the top of `rexlib`, not in a submodule, matching the C++
side where they are in `rexlib` itself and the array libraries they are used
alongside. `dispatch` and `hardware` stay submodules: they are reached for
when setting up, not when computing.

ruff is the authority and runs in CI as `ruff check .`. Its configuration is
`ruff.toml`; `D206` is disabled because the project indents with tabs.

### Comments

Say **what**, never **why**. The why belongs in the commit message and the
pull request. And only say the what when the code does not already: if a
reader understands the line without the comment, the comment does not go in.

There is not a single `TODO` in the repository. Unfinished work is an issue,
not a comment.

## Tests

They are Python tests against the installed package. There are no C++ tests:
the binding has no logic of its own worth testing from C++, and what it does
have is only observable from Python.

`dlpack_buffer` is tested the same way, through `rexlib.from_dlpack`.
`tests/ndarray/test_dlpack.py` builds a tensor by hand with `ctypes` for it:
one whose releases can be counted, and which can be what a library does not
export, such as a tensor on another device or of another version.

```
./scripts/run-tests.sh
./scripts/run-tests.sh --coverage
```

The package has to be installed with `REXLIB_PYTHON_BUILD_TESTING=ON`, which
is what builds the dummy plugins in `tests/assets/`. The runner sets pytest's
rootdir to the repository and, with `--coverage`, writes `coverage.xml`
against `conf/coverage.ini`, which maps `python/rexlib` onto the installed
copy the tests actually import.

`tests/` mirrors the binding's module structure. A test goes in the directory
named after the module whose surface it exercises, not the module it happens
to call through: `tests/dispatch/test_active_context.py` reaches `rexlib.zeros`
to observe context resolution, and context resolution is what it is about.
Tests for what `_binding` exposes at its top level stay at the root.

| Directory | Covers |
|---|---|
| `tests/` | `Version`, `PluginManager`, `ServiceCatalog` |
| `tests/numerical/` | `NumericalType` |
| `tests/ndarray/` | `ArrayDescriptor`, the operators installed onto `Array`, the buffer protocol and DLPack |
| `tests/hardware/` | Devices, sessions, memory resources, the session pool |
| `tests/dispatch/` | `ExecutionContext`, the active context, `rexlib.device(...)` |
| `tests/functional/` | The operations |

There are no `__init__.py` files and no `conftest.py`. Test module names are
therefore unique across the whole tree, and a fixture belongs to the file that
uses it — several files define a `__setup_context` of their own rather than
sharing one. Keep new fixtures file-local until something actually needs to
share them.

`tests/CMakeLists.txt` descends into `assets/` and nothing else: the Python
files are collected by pytest from where they are, so moving one needs no
change to CMake.

numpy is a test requirement, pinned per Python version from 2.2 to 2.5, all of
which take and give versioned DLPack tensors. What the binding itself does
with a versioned or a read-only tensor is tested with the hand-made one.

torch and JAX are not test requirements. A test that needs one starts with
`pytest.importorskip`, so it runs where the library is installed and is
skipped in CI.

## Pull requests

Whoever opens a pull request assigns it to themselves and gives it the label,
among the repository's own, that matches what it changes: `bug` for a fix,
`enhancement` for something new, `documentation` when only documentation
changes, and so on.

## Continuous integration

| Workflow | Does |
|---|---|
| `build-and-test.yml` | Builds with CMake and with pip across the matrix, runs ruff and the suites, then the SonarQube scan |
| `deploy.yml` | Generates the stubs, builds the wheels and the source distribution, and publishes them |
| `release.yml` | Tags and releases, through the shared workflow of the organisation |
| `clean-up-caches.yml`, `keep-caches-warm.yml` | Manage the Actions cache |

`build_with_cmake` covers Linux with gcc and clang, macOS, and Windows on both
architectures; it exists to keep the plain CMake path working and to produce
the compilation database the scanner reads. `build_with_pip` is the one that
runs the tests, across five platforms and Python 3.10 through 3.15, minus
Windows ARM on 3.10, which CPython never shipped there.

Both build rexlib first, into a prefix outside the project, and point the
build at it with `rexlib_ROOT`. It is the bulk of the wall clock, and ccache
is what makes every run after the first a link. The compiler cache and the
fetched sources are saved only on `main`: a pull request reads them and writes
nothing, so one branch cannot evict another's.

Every job moves the submodule to rexlib's `main` before building. That step is
temporary and goes away, along with the Renovate rule holding the submodule
back, once rexlib tags releases.

Coverage is produced by one entry only, Linux on 3.15, and handed to the scan
as an artifact.

### Wheels

`deploy.yml` generates the stubs once, in a job of its own, and hands them to
every wheel — a cross-compiled wheel cannot make its own.

A platform gets a wheel for 3.10, one for 3.11, one abi3 wheel for 3.12 and
every later CPython, and one for each free-threaded interpreter. cibuildwheel
builds the abi3 one for 3.12, finds it compatible with each later interpreter,
tests it there instead of building again, and checks it with `abi3audit`. The
macOS x86_64 wheels target 10.14, the oldest nanobind supports. The wheels then
build rexlib from `external/rexlib` rather than being pointed at one, so that
cibuildwheel's architecture, deployment target and SDK apply to it too instead
of having to be repeated to a step outside.

The wheel carries librexlib itself, put there by this project's install rules,
and every repair tool is told to leave it alone: `auditwheel --exclude`,
`delvewheel --exclude`, `delocate --ignore-missing-dependencies`. Vendoring it
would rename it under a hash-mangled SONAME, which breaks `find_package` for
plugin authors and the sibling directory the plugins are discovered in. The
namelink is excluded from the wheel instead, since a wheel stores a symlink as
another full copy.

musllinux is skipped: NVIDIA ships no CUDA for musl, so rexlib-cuda is
manylinux only and an Alpine install could never reach the GPU backend. Alpine
can still build from the source distribution.

`scripts/check_wheels_agree.py` asserts that every wheel of a platform carries
the same rexlib, which is what makes reusing rexlib's objects between
interpreters sound rather than assumed.

The source distribution names `external/rexlib/**` explicitly, because
`git ls-files` does not report a submodule's contents and the archive would
otherwise carry an empty directory and fail to build.

The job that installs that distribution sets `SKBUILD_BUILD_DIR`, which is
what lets its compiler cache work. scikit-build-core otherwise builds in a
temporary directory of its own, unrelated to the one pip unpacked the archive
into, so the sources sit at a different place relative to the build directory
on every run and `CCACHE_BASEDIR` has nothing stable to rewrite against. The
value has to stay relative — scikit-build-core resolves it against the source
directory, and an absolute one would leave the sources where they were.

Publishing to PyPI is wired up but disabled. Every push to `main` updates the
`development` pre-release with its binaries.
